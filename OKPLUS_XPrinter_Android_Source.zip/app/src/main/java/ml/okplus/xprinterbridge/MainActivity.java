package ml.okplus.xprinterbridge;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 41;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter adapter;
    private Spinner devicesSpinner;
    private ArrayList<BluetoothDevice> devices = new ArrayList<>();
    private EditText receiptText;
    private TextView status;
    private Button refreshButton, printButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        adapter = BluetoothAdapter.getDefaultAdapter();
        buildUi();
        requestBluetoothPermission();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFFFFFFF);

        TextView title = new TextView(this);
        title.setText("OKPLUS XPrinter");
        title.setTextSize(25);
        title.setTextColor(0xFF17202A);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Passerelle d'impression Bluetooth pour tickets thermiques ESC/POS.");
        intro.setTextSize(14);
        root.addView(intro);

        TextView label = new TextView(this);
        label.setText("1. Choisir une imprimante déjà appairée dans les paramètres Android");
        label.setPadding(0, dp(18), 0, dp(6));
        root.addView(label);

        devicesSpinner = new Spinner(this);
        root.addView(devicesSpinner, new LinearLayout.LayoutParams(-1, dp(52)));

        refreshButton = new Button(this);
        refreshButton.setText("Actualiser les imprimantes appairées");
        refreshButton.setOnClickListener(v -> loadPairedDevices());
        root.addView(refreshButton);

        TextView sampleLabel = new TextView(this);
        sampleLabel.setText("2. Texte de test");
        sampleLabel.setPadding(0, dp(16), 0, dp(6));
        root.addView(sampleLabel);

        receiptText = new EditText(this);
        receiptText.setGravity( android.view.Gravity.TOP | android.view.Gravity.START);
        receiptText.setMinLines(7);
        receiptText.setText("       OKPLUS\n      TEST IMPRESSION\n--------------------------------\nArticle        Qté     Prix\nTest             1     500 F\n--------------------------------\nTOTAL                 500 F\n\nMerci de votre visite !\n\n\n");
        receiptText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(receiptText, new LinearLayout.LayoutParams(-1, 0, 1));

        printButton = new Button(this);
        printButton.setText("IMPRIMER LE TEST");
        printButton.setOnClickListener(v -> printTest());
        root.addView(printButton);

        status = new TextView(this);
        status.setText("État : en attente");
        status.setTextSize(14);
        status.setPadding(0, dp(12), 0, 0);
        root.addView(status);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private void requestBluetoothPermission() {
        if (adapter == null) { status.setText("Bluetooth indisponible sur cet appareil."); return; }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        } else {
            loadPairedDevices();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_BT) {
            boolean ok = true;
            for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) loadPairedDevices();
            else status.setText("Autorisation Bluetooth refusée. Autorisez Bluetooth dans les paramètres.");
        }
    }

    private void loadPairedDevices() {
        if (adapter == null) return;
        try {
            if (!adapter.isEnabled()) {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BT + 1);
                status.setText("Activez le Bluetooth.");
                return;
            }
            Set<BluetoothDevice> paired = adapter.getBondedDevices();
            devices.clear();
            ArrayList<String> names = new ArrayList<>();
            for (BluetoothDevice d : paired) {
                devices.add(d);
                String name;
                try { name = d.getName(); } catch (SecurityException e) { name = "Appareil Bluetooth"; }
                names.add((name == null ? "Appareil Bluetooth" : name) + " — " + d.getAddress());
            }
            if (names.isEmpty()) names.add("Aucune imprimante appairée");
            devicesSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
            status.setText("Appareils appairés : " + devices.size() + ". L'imprimante doit d'abord être appairée dans Android.");
        } catch (SecurityException e) {
            status.setText("Autorisation Bluetooth manquante.");
        }
    }

    private void printTest() {
        if (devices.isEmpty() || devicesSpinner.getSelectedItemPosition() < 0) {
            status.setText("Aucune imprimante appairée. Appairez la Xprinter dans les paramètres Bluetooth Android.");
            return;
        }
        BluetoothDevice device = devices.get(devicesSpinner.getSelectedItemPosition());
        String text = receiptText.getText().toString();
        printButton.setEnabled(false);
        status.setText("Connexion à l'imprimante…");
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40}); // ESC @ : initialize
                out.write(new byte[]{0x1B, 0x61, 0x00}); // left align
                out.write(text.getBytes(Charset.forName("CP437")));
                out.write(new byte[]{0x0A, 0x0A, 0x0A});
                out.write(new byte[]{0x1D, 0x56, 0x00}); // cut command, ignored by many small printers
                out.flush();
                runOnUiThread(() -> status.setText("Données envoyées. Vérifiez le ticket imprimé."));
            } catch (Exception e) {
                String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                runOnUiThread(() -> status.setText("Échec d'impression : " + msg + ". Vérifiez Bluetooth/SPP et l'appairage."));
            } finally {
                try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                runOnUiThread(() -> printButton.setEnabled(true));
            }
        }).start();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_BT + 1) loadPairedDevices();
    }
}
