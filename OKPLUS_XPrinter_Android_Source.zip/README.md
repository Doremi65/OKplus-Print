# OKPLUS XPrinter — prototype Android

Prototype source Android natif pour tester l'impression de texte vers une imprimante Bluetooth classique (Bluetooth SPP / ESC-POS).

## Important
- Ce projet est un prototype source, pas un APK installé ou signé.
- Il suppose que la Xprinter accepte le Bluetooth classique SPP avec UUID RFCOMM standard. Si le modèle utilise BLE uniquement ou un protocole propriétaire, le code doit être adapté.
- Il ne s'intègre pas encore automatiquement à sm.okplus.ml. Cette intégration nécessite un pont Web-vers-Android ou une modification du site.
- Appairez d'abord l'imprimante dans Paramètres Android > Bluetooth.
- L'application imprime un ticket de test éditable.
- Le code envoie du texte encodé CP437 et des commandes ESC/POS simples. Les caractères accentués peuvent nécessiter un autre encodage selon le firmware.

## Construction
Ouvrir le dossier dans Android Studio récent, synchroniser Gradle, puis construire l'APK via Build > Build APK(s).
